# Como utilizarlo

Primero descargar el archivo dando click en el botón verde que dice **Code** y guardalo como un .zip

Dentro de vscode copia y pega este comando para instalar las librerías necesarias

```
pip install -r requirements.txt
```

Ejecuta el comando desde la pestaña de debug o con el comando

```
python grammar.py
```

